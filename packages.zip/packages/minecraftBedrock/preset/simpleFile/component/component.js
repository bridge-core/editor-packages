export default defineComponent(({ name, template, schema }) => {
	name('')
	schema({})

	template(() => {})
})
