export default defineCommandSelector(({ name, template }) => {
	name('')

	template(() => {})
})
